import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame {
	
	int frameWidth;		//������ ��
	int frameHeight;	//������ ����
	int day=30;
	
	BufferedImage image;	//��� �̹���
	int width;
	int height;
	
	public void setFrameSize(int frameWidth, int frameHeight) {
		this.frameWidth=frameWidth;
		this.frameHeight=frameHeight;
	}
	public MainFrame(Status status) {
		setLayout(new GridLayout(0, 3, 0, 0));
		
		JPanel leftPanel=new JPanel();
		
		JPanel statusPanel=new JPanel();
		statusPanel.setLayout(new GridLayout(0, 1, 0, 15));
		
		JLabel fatLabel=new JLabel("FAT	 | "+status.iFat);
		JLabel muscleLabel=new JLabel("MUSCLE	 | 	"+status.iMuscle);
		JLabel satietyLabel=new JLabel("SATIETY	 | 	"+status.iSatiety);
		JLabel fatigueLabel=new JLabel("FATIGUE	 | 	"+status.iFatigue);
		JLabel pleasureLabel=new JLabel("PLEASURE	 | 	"+status.iPleasure);
		JLabel dayLabel=new JLabel("D-DAY	 | 	"+day);
		
		fatLabel.setHorizontalAlignment(SwingConstants.LEFT);
		muscleLabel.setHorizontalAlignment(SwingConstants.LEFT);
		satietyLabel.setHorizontalAlignment(SwingConstants.LEFT);
		fatigueLabel.setHorizontalAlignment(SwingConstants.LEFT);
		pleasureLabel.setHorizontalAlignment(SwingConstants.LEFT);
		dayLabel.setHorizontalAlignment(SwingConstants.LEFT);
		
		//---------------- status (��) -----------------//
		
		JPanel centerPanel=new JPanel();

		JLabel imageLabel = new JLabel(new ImageIcon("people-W.jpg"));
		imageLabel.setHorizontalAlignment(JLabel.CENTER);
		centerPanel.add(imageLabel);
		
		//---------------- �׸� (�߰�) --------------------//
		
		JPanel rightPanel=new JPanel();
		
		JPanel activityPanel=new JPanel();
		activityPanel.setLayout(new GridLayout(0, 1, 10, 10));
		
		JPanel exercisePanel=new JPanel();
		exercisePanel.setLayout(new GridLayout(0, 3, 10, 10));
		JButton healthPTButton=new JButton("HealthPT");
		JButton sportsButton=new JButton("Sports");
		JButton militaryArtsButton=new JButton("MilitaryArts");
		
		JPanel studyPanel=new JPanel();
		studyPanel.setLayout(new GridLayout(0, 3, 10, 10));
		JButton physicsButton=new JButton("Physics");
		JButton foodNutritionButton=new JButton("FoodNutrition");
		JButton healthCareButton=new JButton("HealthCare");
		
		JPanel relaxPanel=new JPanel();
		relaxPanel.setLayout(new GridLayout(0, 3, 10, 10));
		JButton eatingButton=new JButton("Eating");
		JButton YOLOButton=new JButton("YOLO");
		JButton doingNothingButton=new JButton("DoingNothing");
		
		/* ��ư ũ�� ����
		exercisePanel.setLayout(null);
		studyPanel.setLayout(null);
		relaxPanel.setLayout(null);

		healthPTButton.setSize(150, 150);
		sportsButton.setSize(150, 150);
		militaryArtsButton.setSize(150, 150);
		physicsButton.setSize(150, 150);
		foodNutritionButton.setSize(150, 150);
		healthCareButton.setSize(150, 150);
		eatingButton.setSize(150, 150);
		YOLOButton.setSize(150, 150);
		doingNothingButton.setSize(150, 150);
		*/
		
		//----------------- �ൿ (������) -----------------//

		add(leftPanel, BorderLayout.WEST);
		add(centerPanel, BorderLayout.CENTER);
		add(rightPanel, BorderLayout.EAST);
		
		leftPanel.add(statusPanel);
		statusPanel.add(fatLabel);
		statusPanel.add(muscleLabel);
		statusPanel.add(satietyLabel);
		statusPanel.add(fatigueLabel);
		statusPanel.add(pleasureLabel);
		statusPanel.add(dayLabel);
		
		rightPanel.add(activityPanel);
		activityPanel.add(exercisePanel);
		exercisePanel.add(healthPTButton);
		exercisePanel.add(sportsButton);
		exercisePanel.add(militaryArtsButton);
		activityPanel.add(studyPanel);
		studyPanel.add(physicsButton);
		studyPanel.add(foodNutritionButton);
		studyPanel.add(healthCareButton);
		activityPanel.add(relaxPanel);
		relaxPanel.add(eatingButton);
		relaxPanel.add(YOLOButton);
		relaxPanel.add(doingNothingButton);
		
		//------------------- �߰� â ---------------------//
		
		Toolkit kit=Toolkit.getDefaultToolkit();	//���� ����
		Dimension screenSize=kit.getScreenSize();	//ȭ�� ũ�� ���� ��ü
		
		setFrameSize(600, 275);
		
		setSize(frameWidth, frameHeight);
		setLocation((screenSize.width-frameWidth)/2, (screenSize.height-frameHeight)/2);	//��ġ
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("�Ͻ���");
		setVisible(true);
		
		setLayout(new FlowLayout());	//��ġ ������ ����
		
		//---------------������� ������ ����-----------------//
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Status status=new Status();
		MainFrame mainFrame=new MainFrame(status);

	}

}
